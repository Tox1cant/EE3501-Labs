    #include "mbed.h"
    
    DigitalOut myLed(LED1);

    DigitalIn myButton(BUTTON1);

    int main() {
    
    while (1){
    
        if (myButton ==1){
    
        wait (0.1);
    
        if (myButton ==1)
    
        myLed=1;
    
        else
    
        myLed=0;
    
        }
    
    }
    
 }