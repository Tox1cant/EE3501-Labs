    #include "mbed.h"
    
    DigitalOut myLed(LED1);

    DigitalIn myButton(BUTTON1);

       
bool buttonDown = false;
 
main() {
 while (true) {  // run forever
  if (myButton) {  // button is pressed
     if  (!buttonDown) {  // a new button press
      myLed = !myLed;                 // toogle LED
      buttonDown = true;     // record that the button is now down so we don't count one press lots of times
      wait_ms(10);              // ignore anything for 10ms, a very basic way to de-bounce the button. 
     } 
   } else { // button isn't pressed
    buttonDown = false;
   }
 }
}