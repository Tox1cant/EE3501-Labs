#include "mbed.h"

PwmOut led(LED1);
AnalogIn analog_value(PA_0);

int main()
{
    float meas_r;
    float meas_v;
   
    printf("\nAnalogIn example\n");
   
    while(1)
    {
        meas_r = analog_value.read();
        meas_v = meas_r*3300;
        printf("Measure = %f = %.0f mV\n\r", meas_r, meas_v);
       
        if(meas_v < 1000)
        {
            led = 1;
        }
        else
        {
            led = 0;
        }
        wait(1.0);
        {
            while(1)
            {
                led = analog_value;
                wait(0.01);
            }
            printf ("Normalized: 0x%04X \n\r", analog_value.read_u16());
            wait(0.01);
        }
    }
} 
