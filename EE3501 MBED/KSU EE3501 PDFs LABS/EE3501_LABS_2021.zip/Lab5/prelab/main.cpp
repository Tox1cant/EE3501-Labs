#include "mbed.h" 

AnalogIn aPin (A0);
DigitalOut led(LED1);

int main()
{
    while(1) {
        float Ain;
        int AinU16;
        Ain = aPin.read();
        AinU16 = aPin.read_u16();
        printf (" Hexadecimal = %d\n" , (AinU16));
        led = !led;
        wait(1.0);
    }
}
