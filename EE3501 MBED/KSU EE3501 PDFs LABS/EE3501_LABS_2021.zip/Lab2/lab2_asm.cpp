#include "mbed.h"


DigitalOut myled(LED1);
Timer t;
int begin, end;


extern "C" void delay_asm(void);


int main() {

    while(1) {
        t.start();//can comment out and manually measure time
        begin = t.read_ms();//can comment out and manually measure time

                delay_asm();

                myled = !myled; // invert LED state
                
        end = t.read_ms();//can comment out and manually measure time
        printf("LED on/off time = %d ms \n", end - begin);//can comment out and manually measure time
        t.stop();//can comment out and manually measure time

    }

}
