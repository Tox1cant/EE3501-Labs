#include "mbed.h"

DigitalOut led1(LED1);
extern "C" int add_asm(int a, int b);

int main()
{
    while(true) {
        printf("Hello ARM world.\n");
        printf("Assembler: %d + %d = %d\n", 2, 3, add_asm(2,3));
        asm("AND R0,R0");
      
        led1 = !led1;
        wait(0.5);
       
    }
}