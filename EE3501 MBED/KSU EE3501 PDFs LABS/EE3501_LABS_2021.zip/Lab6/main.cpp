#include "mbed.h"
Timeout flipper;
DigitalOut led(LED1);
InterruptIn press(BUTTON1);

void down(){
    led = !led;
    
}

void up(){
    flipper.attach(&down, 1.0);
       
}

/*
void toggle(){
            led = !led;
}
*/

int main(){
    led = 0;
    press.fall(&down);    
    press.rise(&up);
    while(1) {     
    }
}
