#include "mbed.h"

DigitalOut led(LED1);

int main()
{
    while(1) {
        printf("Hello ARM world.\n");
        led = 1; // LED is ON
        wait(1); // 500 ms
        led = 0; // LED is OFF
        printf("Goodbye ARM world.\n");
        wait(1); // 500 ms
    }
}
