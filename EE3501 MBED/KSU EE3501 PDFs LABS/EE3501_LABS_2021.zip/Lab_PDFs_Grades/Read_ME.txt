Hello Fellow EES from Kennesaw State University (SPSU)

The PDFs for this class labs will be located in a chared file hosted on Google Drive.

The grades that have been recived for these codes are as follows:

Lab #                   Grade(%)           Missing point areas
    1                   100                 - n/a
    2                   84.29               - BONUS part, Questions: 2,3 partial credit 
    3                   93.6                - Questions: 2,3 partial credit
    4                   70                  - Lab results step 5 (3/5 points) and LED (pressing * - Missing)
    5                   100                 - n/a
    6                   was not recived     - HE IS LAZY ADN WILL TAKE A HOT 40DAYS BEFORE YOU GET YUOR GRADE
    
    
    
GOOGLE DRIVE LINK: https://drive.google.com/drive/folders/1sV9k5zto_mpOxk9FAQg1aaC3KUo3va_1?usp=sharing

ALL ORIGINAL FILES ARE NON-MALITIUS (ORIGINAL FILES FROM D2L CLASS PAGE AND MBED) #####Can not be edited#####

YOU CAN EDIT AND I HAVE GOOD FATE THAT YOU WILL UPDATE THESE DERECTORIES WHILE RETAINING THE LEGACY LABS

IF YOU ARE FROM A DIFFERENT UNIVERSITY AND FOUND THIS HELPFULL ADD TO THE GOOGLE DRIVE.

ANY EDITS THAT YOU MAKE TO THE CODE SHARE THE PROGRAM ON THE GOOGLE DRIVE BY EXPORTING IT FROM MBED


ORIGINAL PUBLICATION DATE: DEC 2021


    